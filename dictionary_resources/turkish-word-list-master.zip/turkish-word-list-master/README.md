# Turkish Word/Phrase List

This list is created and can be maintained via [VikiSözlük](http://tr.wiktionary.org/wiki/Vikisözlük:Sözcük_listesi). `collector.py` file can be used to get the most recent list and write it to a file.

## Statistics
- total number of words/phrases: 63840